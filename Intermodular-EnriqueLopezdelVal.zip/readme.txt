Se adjunta la base de datos del proyecto en formato sql. Para poder cargar correctamente la página, es necesario cargar la base de datos en servidor local (localhost). Se puede cargar por ejemplo en phpmyadmin con los siguientes datos:

Nombre de la base de datos: webRoubaix
username: root
password: 

Si se quiere usar otro nombre de base de datos, usuario y/o contraseña se deben modificar también en el archivo db.php contenido en la carpeta config.
